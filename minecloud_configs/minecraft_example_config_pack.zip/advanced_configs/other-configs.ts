// Set to true so to avoid roll back when EC2 init fail, mainly used for debugging.
export const IGNORE_FAILURE_ON_INSTANCE_INIT = false;
