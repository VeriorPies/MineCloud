export const MINECRAFT_SERVER_DOWNLOAD_URL =
  'https://piston-data.mojang.com/v1/objects/8f3112a1049751cc472ec13e397eade5336ca7ae/server.jar';
