// Factorio 1.1.80 linux headless server download URL
// Replace this URL to switch version
// Other version's download link can be found at https://www.factorio.com/download/archive
// (Note: Only version after 1.1.68 support headless server)
export const FACTORIO_SERVER_DOWNLOAD_URL =
  'https://www.factorio.com/get-download/1.1.80/headless/linux64';
