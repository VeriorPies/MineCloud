// MineCloud Version: 1.2.2

// ---------------- Required -------------------- //
export const AWS_ACCOUNT_ID = '115148907208';
export const AWS_REGION = 'us-west-2';

export const DISCORD_APP_ID = '1104825895019102288';
export const DISCORD_PUBLIC_KEY =
  'ad2c9539d6e7d2158c73d557667c2b24eb9cfe14c10d9acdcf604069dc4a5cc2';
export const DISCORD_BOT_TOKEN =
  'MTEwNDgyNTg5NTAxOTEwMjI4OA.G957o9.2yOLC26qsqLpATiqlG2LnVegJasgImxfh5ORKE';
export const DISCORD_CHANNEL_WEB_HOOK =
  'https://discord.com/api/webhooks/1102307896089387108/lgVq1ZrDfERUNNGFXm-YmbcQhKtz61T1D8RlrXoFbhvjSw4oj9Y2iWHqWBp9Iw0TEsEC';

// ------------- CloudFormation ------------- //
export const STACK_NAME = 'Factorio';

// -------------- Server Executable ------------- //
// If set to true, /minecloud_configs/server/server.zip will be deployed
export const DEPLOY_LOCAL_SERVER_EXECUTABLE = false;

// ----------------EC2 Machine Settings-------------------- //
// EC2 max price per hours, in dollars
export const MAX_PRICE = 0.1;
// EC2 instance type, refer to https://aws.amazon.com/ec2/instance-types/ for more info
export const EC2_INSTANCE_TYPE = 't2.large';
// Disk size, in GB
export const EC2_VOLUME = 16;
// Init time out, in minutes
export const EC2_INIT_TIMEOUT = 15;

// --------------- Backup Settings------------------ //
// At most how many backups
export const MAX_BACKUP_COUNT = 3;
export const BACKUP_INTERVAL_IN_SECONDS = 10800;
