export const VALHEIM_SERVER_NAME = 'MC_VALHEIM';
export const VALHEIM_WORLD = 'MC_DEDICATED';
export const VALHEIM_PASSWORD = 'secret';