#!/bin/sh

echo "Starting Terraria server"
# You can adjust your server start up command here
./TerrariaServer.bin.x86_64 -config serverconfig.txt
echo "Terraria server stop"