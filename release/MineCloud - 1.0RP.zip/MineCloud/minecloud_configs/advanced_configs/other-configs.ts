export const IGNORE_FAILURE_ON_INSTANCE_INIT = false;
