import { Construct } from 'constructs/lib/construct';
import { STACK_PREFIX } from './mine-cloud-stack';
import {
  Runtime,
  FunctionUrlAuthType,
  FunctionUrl
} from 'aws-cdk-lib/aws-lambda';
import path = require('path');
import { PolicyStatement, Policy } from 'aws-cdk-lib/aws-iam';
import { NodejsFunction } from 'aws-cdk-lib/aws-lambda-nodejs';
import { Duration } from 'aws-cdk-lib';
import { DISCORD_APP_ID } from '../minecloud_configs/MineCloud-Configs';

export interface DiscordInteractionsEndpointConstructProps {
  instanceId: string;
  ec2Region: string;
  discordPublicKey: string;
}

export class DiscordInteractionsEndpointConstruct extends Construct {
  readonly discordInteractionsEndpoint;
  readonly discordCommandProcesser;
  readonly lambdaFunctionURL: FunctionUrl;

  constructor(
    scope: Construct,
    id: string,
    props: DiscordInteractionsEndpointConstructProps
  ) {
    super(scope, id);

    this.discordInteractionsEndpoint = new NodejsFunction(
      this,
      `${STACK_PREFIX}_discord_interactions_endpoint_lambda`,
      {
        functionName: `discord_interactions_endpoint_lambda`,
        runtime: Runtime.NODEJS_18_X,
        handler: 'index.handler',
        entry: path.join(
          __dirname,
          '/../lambda/discord_interactions_endpoint/index.ts'
        ),
        environment: {
          PUBLIC_KEY: props.discordPublicKey
        },
        memorySize: 1024 // To reduce cold start time
      }
    );

    this.discordCommandProcesser = new NodejsFunction(
      this,
      `${STACK_PREFIX}_discord_command_processor_lambda`,
      {
        functionName: 'discord_command_processor_lambda',
        runtime: Runtime.NODEJS_18_X,
        handler: 'index.handler',
        entry: path.join(
          __dirname,
          '/../lambda/discord_command_processer/index.ts'
        ),
        environment: {
          INSTANCE_ID: props.instanceId,
          EC2_REGION: props.ec2Region,
          APP_ID: DISCORD_APP_ID
        },
        timeout: Duration.seconds(15)
      }
    );
    this.discordCommandProcesser.grantInvoke(this.discordInteractionsEndpoint);

    const ec2Policy = new PolicyStatement({
      actions: ['ec2:*'],
      resources: ['arn:aws:ec2:*']
    });

    const ec2SSMPolicy = new PolicyStatement({
      actions: ['ssm:SendCommand'],
      resources: ['*']
    });

    this.discordCommandProcesser.role?.attachInlinePolicy(
      new Policy(
        this,
        `${STACK_PREFIX}_discord_interactions_endpoint_lambda_policy`,
        {
          statements: [ec2Policy, ec2SSMPolicy]
        }
      )
    );

    this.lambdaFunctionURL = this.discordInteractionsEndpoint.addFunctionUrl({
      authType: FunctionUrlAuthType.NONE
    });
  }
}
